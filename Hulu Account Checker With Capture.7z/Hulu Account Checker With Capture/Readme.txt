Drop Auth.json File into Loki.exe and type anything in auth Feaild 


for more Tools, combo, and Cracked Program.  join in www.avinfo.cf