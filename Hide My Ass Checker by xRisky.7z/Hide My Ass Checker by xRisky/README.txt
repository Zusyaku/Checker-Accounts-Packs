﻿╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║ YouTube : https://goo.gl/u4VrES                                              ║
║ 2€ | VPN Shop : https://shoppy.gg/user/xRisky                                ║
║ Twitter : https://twitter.com/c09e                                           ║
║                                                                              ║
║                               -----                                          ║
║                                                                              ║
║ crack.sx : https://crack.sx/member.php?action=profile&uid=93#comments/1      ║
║ Register here : https://crack.sx/member.php?action=register&referrer=93      ║
║                                                                              ║
║                               -----                                          ║
║                                                                              ║
║ Cracked.to : https://cracked.to/member.php?action=profile&uid=18273          ║
║ Register here : https://cracked.to/member.php?action=register&referrer=18273 ║ 
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
  _                        ____    _         _            
 | |__    _   _    __  __ |  _ \  (_)  ___  | | __  _   _ 
 | '_ \  | | | |   \ \/ / | |_) | | | / __| | |/ / | | | |
 | |_) | | |_| |    >  <  |  _ <  | | \__ \ |   <  | |_| |
 |_.__/   \__, |   /_/\_\ |_| \_\ |_| |___/ |_|\_\  \__, |
          |___/                                     |___/ 