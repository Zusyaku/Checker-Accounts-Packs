DarkAio - All in one Checker - 20 Modules - By Team Pentesters

Features: 
[+] Results Saved in different folders (depends on the time when u started the checker + module name)
[+] Telegram & Discord Hits Sender
[+] CLI & Log Based Console
[+] Auto update proxies every 5 minutes
[+] Load proxies from Proxyscrape API, or Custom API, or Proxies.txt
[+] Super Light Weight & Fast 
[+] Threading Optimized & Good API
[+] Customizable Settings (Telegram, Discord Hit Sender)
[+] Bans Bad Proxies (no retry with the same proxy if proxy is bad)
[+] Optimized to use less network and memory consumption

Modules: Surfshark(IOS), Minecraft, Malwarebytes, VyprVpn, NordVpn, Azure, IPVanish, k7 Antivirus, Brainly, Wondershare, Altbalaji, Facebook, GMX(IOS), Picsart, Netflix(IOS), Valorant(API), Nubiles Porn, Linkedin, Twitch TV, Vortex Cloud

How To Use? 

Put your combos inside -> Combos.txt
Put your proxies inside -> proxies.txt

Start "DarkAio v1.exe" Then choose your appropriate settings